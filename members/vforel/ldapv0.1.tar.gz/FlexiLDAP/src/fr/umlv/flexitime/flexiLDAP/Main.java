/*
 * Created on 22 nov. 2004
 */
package fr.umlv.flexitime.flexiLDAP;

/**
 * @author vforel
 */
public class Main {
    public static void main(String[] args){
        if(FlexiLDAP.createConnection("ldapetud.univ-mlv.fr",389,"ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr","vforel","pye5uyZp"))
            System.out.println("test OK");
        else System.out.println("test pas bon");
        if(FlexiLDAP.createConnection("ldapetud.univ-mlv.fr",389,"ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr","vforel","pye5uyZj"))
            System.out.println("test OK");
        else System.out.println("test pas bon");
        String str = FlexiLDAP.getAttribute("mail","dbardi01","ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr");
        System.out.println(str);
        str = FlexiLDAP.getAttribute("displayName","dbardi01","ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr");
        System.out.println(str);
        str = FlexiLDAP.getAttribute("mail","dbardi01","ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr");
        System.out.println(str);
        str = FlexiLDAP.getAttribute("mail","dbardi01","ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr");
        System.out.println(str);
        
    }

}

/*
 * Cr�� le 18 nov. 2004
 * http://java.sun.com/products/jndi/tutorial/ldap/connect/create.html
 */
package fr.umlv.flexitime.flexiLDAPv2;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.NamingException;

/**
 * @author Val�re FOREL
 */
public class FlexiLDAP { 
    public static final int TYPE_USER = 1;
    public static final int TYPE_GROUP = 2;
	private InitialLdapContext ctx = null;
	private String serverLdap = null;
	private int port = -1;
	private String pathUser = null;
	private String pathGroup= null;
	private String loginAs = null;
	
	public FlexiLDAP(){
	    serverLdap = "ldapetud.univ-mlv.fr";
	    port = 389;
	    pathUser = "ou=Users,ou=Etudiant,dc=univ-mlv,dc=fr";
	    pathGroup = "ou=Groups,ou=Etudiant,dc=univ-mlv,dc=fr";
	}
	
	public FlexiLDAP(String serverLdap, int port,String pathUser, String pathGroup){
	    this.serverLdap = serverLdap;
	    this.port = port;
	    this.pathUser = pathUser;
	    this.pathGroup = pathGroup; 
	}
	
	public boolean createConnection(String name, String passwd){
	    if(loginAs!=null && loginAs.equals(name) && ctx!=null) return true;
	    closeConnection();
	    Hashtable env = new Hashtable();
	    //		Creating an Initial Ldap Context
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://"+serverLdap+":"+port+"/");
 		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "uid="+name+","+pathUser);
 		env.put(Context.SECURITY_CREDENTIALS, passwd);

		try {
			//	Getting a Directory Object's Attributes
			ctx = new InitialLdapContext(env,null);
			loginAs = name;
			return true;
			
		} catch (NamingException e) {
		    ctx = null;
			return false;
		} 
	}
	
	public ArrayList getAttribute(String component, int type, String name){
	    if(ctx==null) return null;
	    ArrayList l = null;
	    String str = "";
	    try {
	        if(type==TYPE_USER) str = "uid="+name+","+pathUser;
	        else if(type==TYPE_GROUP) str = "cn="+name+","+pathGroup;
	        else return null;
	        Attributes attrs = ctx.getAttributes(str);
	        Enumeration enum = attrs.getAll();
	        while(enum.hasMoreElements()){
	            Attribute attr = (Attribute)enum.nextElement();
	            if(attr.getID().equals(component)){
	                l = new ArrayList();
	                Enumeration enum2 = attr.getAll();
	                while(enum2.hasMoreElements()){
	                    l.add(enum2.nextElement());
	                }
	                return l;
	            }
	        }
	    } catch (NamingException e) {
	        l = null;
        }
        return l;																						
	}
	
	public void closeConnection(){
	    ctx = null;
	    loginAs = null;
	}
	
	public boolean isConnected(String name){
	    if((name.equals(loginAs)) && (ctx != null)) return true;
	    else return false;
	}
    /**
     * @return Returns the pathGroup.
     */
    public String getPathGroup() {
        return pathGroup;
    }
    /**
     * @param pathGroup The pathGroup to set.
     */
    public void setPathGroup(String pathGroup) {
        this.pathGroup = pathGroup;
    }
    /**
     * @return Returns the pathUser.
     */
    public String getPathUser() {
        return pathUser;
    }
    /**
     * @param pathUser The pathUser to set.
     */
    public void setPathUser(String pathUser) {
        this.pathUser = pathUser;
    }
}

/*
 * Created on 22 nov. 2004
 */
package fr.umlv.flexitime.flexiLDAPv2;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author vforel
 */
public class Main {
    public static void main(String[] args){
        FlexiLDAP f = new FlexiLDAP();
        if(f.createConnection("vforel","pye5uyZp"))
            System.out.println("test OK");
        else System.out.println("test pas bon");
        if(f.createConnection("vforel","pye5uyZj"))
            System.out.println("test OK");
        else System.out.println("test pas bon");
        ArrayList l = f.getAttribute("sn",FlexiLDAP.TYPE_USER,"abouvet");
        Iterator iter = null;
        if(l == null) System.out.println("pas beau!!");
        else{
            iter = l.iterator();
            while (iter.hasNext()) {
                String str = (String) iter.next();
                System.out.println(str);
            }
        }

        ArrayList l2 = f.getAttribute("displayName",FlexiLDAP.TYPE_USER,"abouvet");
        if(l2 == null) System.out.println("pas beau!!");
        else{
            iter = l2.iterator();
            while (iter.hasNext()) {
                String str = (String) iter.next();
                System.out.println(str);
            }
        }
        
        ArrayList l3 = f.getAttribute("mailLocalAddress",FlexiLDAP.TYPE_GROUP,"igin06");
        if(l3 == null) System.out.println("pas beau!!");
        else{
            iter = l3.iterator();
            while (iter.hasNext()) {
                String str = (String) iter.next();
                System.out.println(str);
            }
        }
        
        System.out.println(f.isConnected("vforel"));
        System.out.println(f.isConnected("dbardi01"));
        f.closeConnection();
        
    }
}

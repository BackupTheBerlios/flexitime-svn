/*
 * Cr�� le 18 nov. 2004
 * http://java.sun.com/products/jndi/tutorial/ldap/connect/create.html
 */
package fr.umlv.flexitime.flexiLDAP;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.NamingException;

/**
 * @author Val�re FOREL
 */
public class FlexiLDAP {
	private static Hashtable env = null; 
	private static InitialLdapContext ctx = null;
	
	public static boolean createConnection(String serverLdap, int port,String pathLdap, String name, String passwd){
	    env = new Hashtable();
	    //		Creating an Initial Ldap Context
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://"+serverLdap+":"+port+"/");
 		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "uid="+name+","+pathLdap);
 		env.put(Context.SECURITY_CREDENTIALS, passwd);

		try {
			//	Getting a Directory Object's Attributes
			ctx = new InitialLdapContext(env,null);
			return true;
			
		} catch (NamingException e) {
			return false;
		} 
	}
	
	public static String getAttribute(String component, String name,String pathLdap){
	    if(ctx!=null){
	        HashMap m = new HashMap();
	        try {
	            Attributes attrs = ctx.getAttributes("uid="+name+","+pathLdap);
	            Enumeration enum = attrs.getAll();
	            while(enum.hasMoreElements()){
	                Attribute attr = (Attribute)enum.nextElement();
	                m.put(attr.getID(),attr.get());
	            }
            } catch (NamingException e) {
                m = null;
            }
            
            return (String)m.get(component);
	    }else return null;
	}
}
